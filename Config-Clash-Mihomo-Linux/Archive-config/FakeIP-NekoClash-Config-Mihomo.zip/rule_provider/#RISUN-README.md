# Behavior: classical
# last edited by risunturu
# Credit : reyre, aiqyr, malikshi, dantewrt, zhapers and another.